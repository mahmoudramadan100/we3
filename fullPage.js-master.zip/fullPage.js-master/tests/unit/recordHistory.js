//mockup (apparently location.replace is read only so.... NO TESTS...)

/*
window.location.replace = function(url){
    console.log("weeee");
    locationReplace = url;
};


QUnit.test('Testing recordHistory:false', function(assert) {
    var id = '#fullpage';
    var FP = initFullpageNew(id, Object.assign({}, allBasicOptions, {recordHistory: false}));
    var windowHeight = $(window).height();

    FP.moveSectionDown();
    assert.equal(locationReplace, '#page2', 'We expect section 3 to be active');
});
*/